package com.evyatartzik.android2_project.Notifictions;

public class MyResponse {
    public int success;
}
