package com.evyatartzik.android2_project.Notifictions;

public class Token {

    private String Token;

    public Token(String token) {
        Token = token;
    }

    public Token() {
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }
}
