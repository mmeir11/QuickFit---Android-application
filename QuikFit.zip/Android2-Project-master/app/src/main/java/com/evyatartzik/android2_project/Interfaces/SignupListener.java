package com.evyatartzik.android2_project.Interfaces;

public interface SignupListener {
    void finish_signup();
}
