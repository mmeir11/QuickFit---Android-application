package com.evyatartzik.android2_project.Models;

public enum Step {
    Step1,
    Step2,
    Step3
}
