package com.evyatartzik.android2_project.Interfaces;

public interface FragmentToActivity {

    void finish_task(int id, String str, String str2);

}
